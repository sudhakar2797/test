import React,{Component} from 'react';

class StepBlocker extends Component{
  render(){
    return(

      <ul className="list-group list-group-flush">
        <div className="row">
        <div className="col-lg-3 col-md-12 col-sm-12" ></div>
        <div className="col-lg-6 col-md-12 col-sm-12 card shadow-lg p-3 m-4  mb-5 bg-white rounded border border-warning">
        <center><h5><i className="fa fa-exclamation-triangle fa-3x"></i><br/>Please Complete previous Step's Before Further Process</h5>
        </center>
        </div>
        <div className="col-lg-3 col-md-12 col-sm-12" ></div>
        </div>

          
        </ul>

    );
  }
}
export default StepBlocker;
