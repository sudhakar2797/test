import React, { Component } from "react";
import stringSimilarity from "string-similarity";
import { Link } from "react-router-dom";
import "./style.css";

let webkitSpeechRecognition = window.webkitSpeechRecognition;
const SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
const recognition = new SpeechRecognition();
let synth = window.speechSynthesis;

recognition.continous = true;
recognition.interimResults = true;
recognition.lang = "en-UK";

class ChatWindow extends Component {
  constructor(props) {
    super(props);
    this.state = {
    //  jsonData: this.props.location.state.jsonData,
    jsonData:[['hello','hello'],['hello','hello']],
      testerClass: "talk-bubble tri-right left-top d-none",
      alexaClass: "talk-bubble tri-right right-top d-none",
      testerMessage: "",
      alexaMessage: "",
      testerStatus: true,
      alexaStatus: true,
      counter: 0,
      listening: false,
      showReport: false,
      beginStatus: false,
      testcasecount: 0
    };
  }

  begin = () => {
    this.setState({ beginStatus: true });
    let cnt = 0;
    if (this.state.counter < this.state.jsonData.length) {
      let message = this.state.jsonData[this.state.counter][0];
      if (message === "WakeUpText") {
        message =
          this.state.jsonData[this.state.counter][1];

		  let speakMessageInitial = new SpeechSynthesisUtterance(
        message.toLowerCase()
      );
      speakMessageInitial.voice = speechSynthesis.getVoices().filter(function(voice) {
    return voice.name == "Google UK English Female"
  })[0];
      speakMessageInitial.volume = 1;
      speakMessageInitial.rate= 1;
      speakMessageInitial.pitch = 1;
      synth.speak(speakMessageInitial);

		  message=  this.state.jsonData[this.state.counter + 1][0];

        cnt = cnt + 1;
        this.setState({ testcasecount: this.state.testcasecount + 1 });
      }
      this.setState({
        testerClass: "talk-bubble tri-right left-top",
        testerMessage: message,
        counter: this.state.counter + 1 + cnt,
        continueClass: "btn btn-success"
      });
      let speakMessage = new SpeechSynthesisUtterance(
        message.toLowerCase()
      );
      speakMessage.voice = speechSynthesis.getVoices().filter(function(voice) {
    return voice.name == "Google UK English Female"
  })[0];
      speakMessage.volume = 1;
      speakMessage.rate= 1;
      speakMessage.pitch = 1;
      synth.speak(speakMessage);
      speakMessage.onend = () => {
        this.setState({ listening: !this.state.listening }, this.handleListen);
      };
    } else if (this.state.counter === this.state.jsonData.length) {
      this.setState({ showReport: true });
    }
  };
  again = () => {
    let compare = 0;
    this.state.jsonData[this.state.counter - 1][2] = this.state.alexaMessage;
    if (this.state.jsonData[this.state.counter - 1].length === 3) {
      compare = stringSimilarity.compareTwoStrings(
        this.state.jsonData[this.state.counter - 1][1],
        this.state.jsonData[this.state.counter - 1][2]
      );
      this.state.jsonData[this.state.counter - 1].push(compare);
    }
    this.setState(
      {
        listening: !this.state.listening,
        alexaClass: "talk-bubble tri-right right-top d-none",
        testerClass: "talk-bubble tri-right left-top d-none"
      },
      this.handleListen
    );
    if (compare < 0.8) {
      let flag=false;
      for (let i = this.state.counter; i < this.state.jsonData.length; i++) {
        if (this.state.jsonData[i][0] === "WakeUpText") {
          flag=true;
          this.setState({ counter: i });
        }
      }
      if(flag===false){
        this.setState({counter:this.state.jsonData.length})
      }
    }
    setTimeout(this.begin, 0);
    console.log(this.state.jsonData);
  };
  handleListen() {
    console.log("listening?", this.state.listening);

    if (this.state.listening) {
      recognition.start();
      recognition.onend = () => {
        console.log("...continue listening...");
        recognition.start();
      };
    } else {
      recognition.stop();
      recognition.onend = () => {
        console.log("Stopped listening per click");
      };
    }

    recognition.onstart = () => {
      console.log("Listening!");
    };

    let finalTranscript = "";
    recognition.onresult = event => {
      let interimTranscript = "";

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalTranscript += transcript + " ";
        else interimTranscript += transcript;
      }
      this.setState({
        alexaMessage: finalTranscript,
        alexaClass: "talk-bubble tri-right right-top"
      });

      const transcriptArr = finalTranscript.split(" ");
      const stopCmd = transcriptArr.slice(-3, -1);
      console.log("stopCmd", stopCmd);

      if (stopCmd[0] === "stop" && stopCmd[1] === "listening") {
        recognition.stop();
        recognition.onend = () => {
          console.log("Stopped listening per command");
          const finalText = transcriptArr.slice(0, -3).join(" ");
        };
      }
    };

    recognition.onerror = event => {
      console.log("Error occurred in recognition: " + event.error);
      this.again();
    };
  }

  render() {
    return (
      <div>
        <ul className="list-group list-group-flush">
            <div className="row">
              <div className="col-lg-2 col-md-12 col-sm-12">
                </div>
              <div className="col-lg-8 col-md-12 col-sm-12 ">
                <br />
                {this.state.showReport === false ? (
                  <div className="col-lg-12 col-md-12 col-sm-12 ">
                    <button
                      className="btn btn-primary"
                      onClick={this.begin}
                      disabled={this.state.beginStatus}
                    >
                      <i className="fa fa-send" />
                      &nbsp;Let's Begin
                    </button>
                    {this.state.testerStatus === true ? true : false}
                    <div className={this.state.testerClass}>
                      <div className="talktext">
                        <p>{this.state.testerMessage}</p>
                      </div>
                    </div>

                    <div className={this.state.alexaClass}>
                      <div className="talktext">
                        <p>{this.state.alexaMessage}</p>
                      </div>
                    </div>
                    <br />
                    <br />
                    <br />
                  </div>
                ) : (
                  ""
                )}
                {this.state.showReport === true ? (
                  <div className="col-lg-12 col-md-12 col-sm-12 card shadow-lg p-3 m-4  mb-5 bg-white rounded border border-primary">
                    <br />
                    <br />
                    <Link
                      to={{
                        pathname: "/DownloadReport",
                        state: { jsonData: this.state.jsonData }
                      }}
                    >
                      <button className="btn btn-success">
                        <i className="fa fa-desktop" />
                        &nbsp;View Report
                      </button>{" "}
                    </Link>
                    <br />
                    <br />
                  </div>
                ) : (
                  ""
                )}
              </div>
              <div className="col-lg-2 col-md-12 col-sm-12">
              </div>
            </div>
            <br />
            <br />
            
          </ul>
      </div>
    );
  }
}
export default ChatWindow;
