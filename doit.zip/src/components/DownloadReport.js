import React,{Component} from 'react';
class DownloadReport extends Component{
  constructor(props){
    super(props)
    this.state={
    //  reportData:this.props.location.state.jsonData
    reportData:[['hello','hello','hello','1'],['hello','hello','hello','1']],
    }
  }
  exportToCsv = () =>{
    let CsvString = "";
    let Results = this.state.reportData;
    Results.forEach(function(RowItem, RowIndex) {
      RowItem.forEach(function(ColItem, ColIndex) {
        CsvString += ColItem + ',';
      });
      CsvString += "\r\n";
    });
    CsvString = "data:application/csv," + encodeURIComponent(CsvString);
   let x = document.createElement("A");
   x.setAttribute("href", CsvString );
   x.setAttribute("download","AlexaTestResult.csv");
   document.body.appendChild(x);
   x.click();
  }
  render(){
    return(
      <div>


        <button className="btn btn-primary p-2" onClick={this.exportToCsv}><i className="fa fa-download"></i></button>
        <br/><br/>



      <table className="table">
          <thead className="thead-dark">
          <tr>
          <th>Test Case</th>
          <th>Expected Result</th>
          <th>Actual Result</th>
          <th>Similarity</th>
          </tr>
          </thead>
          <tbody>
          {this.state.reportData.map(item=>
              ( <tr key={item}>
                <td key={item[0]}>{item[0]}</td>
                <td key={item[1]}>{item[1]}</td>
                <td key={item[2]}>{item[2]}</td>
                <td key={item[3]}>{item[3]}</td>
                </tr>))
          }
          </tbody>
          </table>


      </div>
    );
  }
}
export default DownloadReport;
