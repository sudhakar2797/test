import React, { Component } from "react";
import * as XLSX from 'xlsx';
import XLToJson from "./XLToJson";
import ChatWindow from "./ChatWindow";
import DownloadReport from "./DownloadReport";
class Home extends Component {
  render() {
    return (
      <div>

      <div class="wizard-form">
        <div class="wizard-header">
          <h3 class="heading">Alexa Automation Testing</h3>

        </div>
            <div class="form-register" >
              <div id="form-total">
                  <h2>
                    <span class="step-icon"><i class="zmdi zmdi-home"></i></span>
                    <span class="step-text">Home</span>
                  </h2>
                  <section>
                      <div class="inner">
                      <center>	<h3>Alexa Automation Testing</h3>
                      <br/><br/><br/><br/></center>

              </div>
                  </section>
                  <h2>
                    <span class="step-icon"><i class="zmdi zmdi-upload"></i></span>
                    <span class="step-text">Upload</span>
                  </h2>
                  <section>
                      <div class="inner">
                        <h3>Upload .csv | .xlsx | .xls File</h3>
                      <br/><br/><br/>
                      <XLToJson />
              </div>
                  </section>
                  <h2>
                    <span class="step-icon"><i class="zmdi zmdi-chart"></i></span>
                    <span class="step-text">progress</span>
                  </h2>
                  <section>
                      <div class="inner">
                        <h3>Test progress</h3>
                        <ChatWindow />
              </div>
                  </section>
                  <h2>
                    <span class="step-icon"><i class="zmdi zmdi-download"></i></span>
                    <span class="step-text">Report</span>
                  </h2>
                  <section>
                      <div class="inner">
                        <h3>Download Test Result</h3>
                        <DownloadReport />
              </div>
                  </section>
              </div>
            </div>
      </div>
      </div>
    );
  }
}
export default Home;
