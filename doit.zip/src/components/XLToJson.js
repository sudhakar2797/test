import React,{Component} from 'react';
import {Link} from 'react-router-dom';

import * as XLSX from 'xlsx';
class XLToJson extends Component{
  constructor(props) {
    super(props);
  this.fileInput = React.createRef();
    this.state={
      showTable:false,
      jsonData: "",
      sno:0
    }
    this.handleSave = this.handleSave.bind(this);
  }
  handleSave = (event) => {
    event.preventDefault();
    alert('hi')

    // const reader = new FileReader();
    // reader.onload = (evt) => {
    //   const bstr = evt.target.result;
    //   const wb = XLSX.read(bstr, {type:'binary'});
    //   const wsname = wb.SheetNames[0];
    //   const ws = wb.Sheets[wsname];
    //   let data = XLSX.utils.sheet_to_csv(ws, {header:1});
    //   let arrdata=data.split("\n");
    //   let finaldata=[];
    //   for(let i=0;i<arrdata.length-1;i++){
    //     finaldata.push(this.splitLine(arrdata[i]));
    //   }
    //   this.setState({showTable: true, jsonData:finaldata});
    //   console.log(this.state.jsonData)
    // };
    // reader.readAsBinaryString(this.fileInput.current.files[0]);
  }
  splitLine(line){
    let lines=line.split(',');
    return lines;
  }

  render(){
    return(

      <ul className="list-group list-group-flush">
      <div className="row">
      <div className="col-lg-1 col-md-12 col-sm-12" ></div>
      <div className="col-lg-10 col-md-12 col-sm-12 ">

      <div className="input-group  p-4">
      <div className="input-group-prepend">
      <span className="input-group-text" id="inputGroupFileAddon01">Upload</span>
      </div>
      <div className="custom-file">
      <input type="file" className="custom-file-input" ref={this.fileInput}  id="inputGroupFile01" aria-describedby="inputGroupFileAddon01"/>
      <label className="custom-file-label" >Choose file</label>
      </div>
    </div>
      <button className="btn btn-primary p-2"  onClick={this.handleSave} ><i className="fa fa-cloud-upload"></i>&nbsp;Submit</button>

      </div>
      <div className="col-lg-1 col-md-12 col-sm-12" ></div>
      </div>
      {this.state.showTable===true ?
          (<div className="col-lg-10 col-md-12 col-sm-12 card shadow-lg p-3 m-4  mb-5 bg-white rounded">
          <table className="table">
          <thead className="thead-dark">
          <tr>
          <th>S.No</th>
          <th>Test Case</th>
          <th>Expected Result</th>
          </tr>
          </thead>
          <tbody>
          {this.state.jsonData.map(item=>
              ( <tr key={item}>
                <th key={this.state.sno}>{this.state.sno=this.state.sno + 1}</th>
                <td key={item[0]}>{item[0]}</td>
                <td key={item[1]}>{item[1]}</td>
                </tr>))
          }
          </tbody>
          </table>
          <br/>
          <Link
              to={{
                pathname: '/ChatWindow',
                state:{jsonData: this.state.jsonData}
          }}><button className="btn btn-success"><i className="fa fa-bar-chart"></i>&nbsp;View Progress</button> </Link>
          <br/>
          </div>) : ""}
      </ul>

          );}}
      export default XLToJson;
